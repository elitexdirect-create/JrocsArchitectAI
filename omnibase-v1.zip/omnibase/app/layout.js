import { JetBrains_Mono, Inter } from 'next/font/google'
import './globals.css'

const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono', weight: ['400', '500', '700'] })
const inter = Inter({ subsets: ['latin'], variable: '--font-body', weight: ['400', '500', '600'] })

export const metadata = {
  title: 'OmniBase',
  description: 'Build a database. No SQL required.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={`${mono.variable} ${inter.variable}`}>{children}</body>
    </html>
  )
}
