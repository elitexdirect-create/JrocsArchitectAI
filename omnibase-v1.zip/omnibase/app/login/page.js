'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const [mode, setMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setStatus(null)
    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) { setStatus({ type: 'error', message: error.message }); setLoading(false); return }
      router.push('/tables'); router.refresh()
    } else {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) { setStatus({ type: 'error', message: error.message }); setLoading(false); return }
      setStatus({ type: 'success', message: 'Account created. Check email to confirm, then sign in.' })
      setMode('login'); setLoading(false)
    }
  }

  return (
    <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      <div style={{ width: '100%', maxWidth: '380px' }}>
        <div style={{ marginBottom: '32px' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--amber)', letterSpacing: '0.08em', marginBottom: '8px' }}>
            OMNIBASE
          </div>
          <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: '22px', fontWeight: 700, margin: 0 }}>
            {mode === 'login' ? 'Sign in' : 'Create your account'}
          </h1>
        </div>
        <form onSubmit={handleSubmit} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '10px', padding: '24px' }}>
          <label style={labelStyle}>Email</label>
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} style={inputStyle} placeholder="you@example.com" />
          <label style={{ ...labelStyle, marginTop: '16px' }}>Password</label>
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} style={inputStyle} placeholder="At least 6 characters" />
          {status && (
            <div style={{ marginTop: '16px', fontSize: '13px', color: status.type === 'error' ? 'var(--danger)' : 'var(--done)', fontFamily: 'var(--font-mono)' }}>
              {status.type === 'error' ? '✕ ' : '✓ '}{status.message}
            </div>
          )}
          <button type="submit" disabled={loading} style={buttonStyle}>
            {loading ? 'Working…' : mode === 'login' ? 'Sign in' : 'Create account'}
          </button>
        </form>
        <button onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setStatus(null) }}
          style={{ marginTop: '16px', background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '13px', cursor: 'pointer', width: '100%', textAlign: 'center' }}>
          {mode === 'login' ? "Don't have an account? Create one" : 'Already have an account? Sign in'}
        </button>
      </div>
    </main>
  )
}

const labelStyle = { display: 'block', fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px', fontFamily: 'var(--font-mono)' }
const inputStyle = { width: '100%', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '6px', padding: '10px 12px', color: 'var(--text)', fontSize: '14px' }
const buttonStyle = { width: '100%', marginTop: '20px', background: 'var(--amber)', color: '#14120f', border: 'none', borderRadius: '6px', padding: '11px', fontSize: '14px', fontWeight: 600, cursor: 'pointer' }
