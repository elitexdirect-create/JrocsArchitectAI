'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'

const FIELD_TYPES = ['text', 'number', 'boolean', 'date']

export default function TableDetailClient({ table, initialFields, initialRecords }) {
  const [fields, setFields] = useState(initialFields)
  const [records, setRecords] = useState(initialRecords)
  const [newFieldName, setNewFieldName] = useState('')
  const [newFieldType, setNewFieldType] = useState('text')
  const supabase = createClient()

  async function addField(e) {
    e.preventDefault()
    const name = newFieldName.trim()
    if (!name) return
    const { data, error } = await supabase
      .from('ob_fields')
      .insert({ table_id: table.id, name, field_type: newFieldType, position: fields.length })
      .select()
      .single()
    if (!error && data) {
      setFields((prev) => [...prev, data])
      setNewFieldName('')
    }
  }

  async function deleteField(fieldId) {
    setFields((prev) => prev.filter((f) => f.id !== fieldId))
    await supabase.from('ob_fields').delete().eq('id', fieldId)
  }

  async function addRecord() {
    const emptyData = Object.fromEntries(fields.map((f) => [f.name, f.field_type === 'boolean' ? false : '']))
    const { data, error } = await supabase
      .from('ob_records')
      .insert({ table_id: table.id, data: emptyData })
      .select()
      .single()
    if (!error && data) setRecords((prev) => [...prev, data])
  }

  async function updateCell(recordId, fieldName, value) {
    setRecords((prev) => prev.map((r) => (r.id === recordId ? { ...r, data: { ...r.data, [fieldName]: value } } : r)))
    const record = records.find((r) => r.id === recordId)
    const newData = { ...record.data, [fieldName]: value }
    await supabase.from('ob_records').update({ data: newData }).eq('id', recordId)
  }

  async function deleteRecord(recordId) {
    setRecords((prev) => prev.filter((r) => r.id !== recordId))
    await supabase.from('ob_records').delete().eq('id', recordId)
  }

  return (
    <main style={{ minHeight: '100vh', padding: '32px 20px' }}>
      <div style={{ maxWidth: '900px', margin: '0 auto' }}>
        <div style={{ marginBottom: '8px' }}>
          <a href="/tables" style={{ fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textDecoration: 'none' }}>
            ← all tables
          </a>
        </div>
        <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: '22px', margin: '0 0 24px' }}>{table.name}</h1>

        {/* Schema builder */}
        <section style={{ marginBottom: '28px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '10px', letterSpacing: '0.05em' }}>
            FIELDS
          </div>
          {fields.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '12px' }}>
              {fields.map((f) => (
                <span key={f.id} style={{
                  display: 'flex', alignItems: 'center', gap: '6px', background: 'var(--surface)',
                  border: '1px solid var(--border)', borderRadius: '6px', padding: '6px 10px', fontSize: '12px',
                }}>
                  {f.name} <span style={{ color: 'var(--text-muted)' }}>({f.field_type})</span>
                  <button onClick={() => deleteField(f.id)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: 0, fontSize: '12px' }}>✕</button>
                </span>
              ))}
            </div>
          )}
          <form onSubmit={addField} style={{ display: 'flex', gap: '8px' }}>
            <input value={newFieldName} onChange={(e) => setNewFieldName(e.target.value)} placeholder="Field name"
              style={{ flex: 1, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px', padding: '9px 10px', color: 'var(--text)', fontSize: '13px' }} />
            <select value={newFieldType} onChange={(e) => setNewFieldType(e.target.value)}
              style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px', padding: '9px 10px', color: 'var(--text)', fontSize: '13px' }}>
              {FIELD_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <button type="submit" style={{ background: 'var(--amber)', color: '#14120f', border: 'none', borderRadius: '6px', padding: '0 16px', fontWeight: 600, fontSize: '13px', cursor: 'pointer' }}>
              Add field
            </button>
          </form>
        </section>

        {/* Record grid */}
        <section>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>
              RECORDS ({records.length})
            </div>
            <button onClick={addRecord} disabled={fields.length === 0}
              style={{ background: fields.length === 0 ? 'var(--surface)' : 'var(--amber)', color: fields.length === 0 ? 'var(--text-muted)' : '#14120f', border: '1px solid var(--border)', borderRadius: '6px', padding: '6px 14px', fontSize: '12px', fontWeight: 600, cursor: fields.length === 0 ? 'not-allowed' : 'pointer' }}>
              + Add record
            </button>
          </div>

          {fields.length === 0 ? (
            <div style={{ border: '1px dashed var(--border)', borderRadius: '8px', padding: '28px 20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px', fontFamily: 'var(--font-mono)' }}>
              Add at least one field above before adding records.
            </div>
          ) : records.length === 0 ? (
            <div style={{ border: '1px dashed var(--border)', borderRadius: '8px', padding: '28px 20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px', fontFamily: 'var(--font-mono)' }}>
              No records yet. Click "Add record" to create the first row.
            </div>
          ) : (
            <div style={{ overflowX: 'auto', border: '1px solid var(--border)', borderRadius: '8px' }}>
              <table>
                <thead>
                  <tr>
                    {fields.map((f) => (
                      <th key={f.id} style={{ textAlign: 'left', fontSize: '12px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', padding: '10px 12px', borderBottom: '1px solid var(--border)', background: 'var(--surface)' }}>
                        {f.name}
                      </th>
                    ))}
                    <th style={{ width: '36px', borderBottom: '1px solid var(--border)', background: 'var(--surface)' }} />
                  </tr>
                </thead>
                <tbody>
                  {records.map((r) => (
                    <tr key={r.id}>
                      {fields.map((f) => (
                        <td key={f.id} style={{ padding: '4px 8px', borderBottom: '1px solid var(--border)' }}>
                          {f.field_type === 'boolean' ? (
                            <input type="checkbox" checked={!!r.data[f.name]} onChange={(e) => updateCell(r.id, f.name, e.target.checked)} />
                          ) : (
                            <input
                              type={f.field_type === 'number' ? 'number' : f.field_type === 'date' ? 'date' : 'text'}
                              value={r.data[f.name] ?? ''}
                              onChange={(e) => updateCell(r.id, f.name, e.target.value)}
                              style={{ width: '100%', background: 'transparent', border: 'none', color: 'var(--text)', fontSize: '13px', padding: '6px 4px' }}
                            />
                          )}
                        </td>
                      ))}
                      <td style={{ borderBottom: '1px solid var(--border)', textAlign: 'center' }}>
                        <button onClick={() => deleteRecord(r.id)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '13px' }}>✕</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  )
}
