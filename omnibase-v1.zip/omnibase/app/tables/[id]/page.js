import { redirect, notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import TableDetailClient from './table-detail-client'

export default async function TableDetailPage({ params }) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: table } = await supabase.from('ob_tables').select('*').eq('id', id).single()
  if (!table) notFound()

  const { data: fields } = await supabase.from('ob_fields').select('*').eq('table_id', id).order('position')
  const { data: records } = await supabase.from('ob_records').select('*').eq('table_id', id).order('created_at')

  return <TableDetailClient table={table} initialFields={fields ?? []} initialRecords={records ?? []} />
}
