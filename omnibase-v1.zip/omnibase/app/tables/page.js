import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import TablesClient from './tables-client'

export default async function TablesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: tables } = await supabase
    .from('ob_tables')
    .select('*')
    .order('created_at', { ascending: true })

  return <TablesClient initialTables={tables ?? []} userEmail={user.email} />
}
