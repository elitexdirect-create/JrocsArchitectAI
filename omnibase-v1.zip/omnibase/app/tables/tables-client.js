'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function TablesClient({ initialTables, userEmail }) {
  const [tables, setTables] = useState(initialTables)
  const [draft, setDraft] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function createTable(e) {
    e.preventDefault()
    const name = draft.trim()
    if (!name) return
    setSubmitting(true)
    const { data, error } = await supabase.from('ob_tables').insert({ name }).select().single()
    if (!error && data) {
      setTables((prev) => [...prev, data])
      setDraft('')
      router.push(`/tables/${data.id}`)
    }
    setSubmitting(false)
  }

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <main style={{ minHeight: '100vh', padding: '32px 20px' }}>
      <div style={{ maxWidth: '640px', margin: '0 auto' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--amber)', letterSpacing: '0.08em', marginBottom: '6px' }}>
              OMNIBASE
            </div>
            <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: '20px', margin: 0 }}>Your tables</h1>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>{userEmail}</div>
          </div>
          <button onClick={signOut} style={{ background: 'none', border: '1px solid var(--border)', color: 'var(--text-muted)', borderRadius: '6px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', fontFamily: 'var(--font-mono)' }}>
            sign out
          </button>
        </header>

        <form onSubmit={createTable} style={{ display: 'flex', gap: '8px', marginBottom: '24px' }}>
          <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="New table name (e.g. Customers)"
            style={{ flex: 1, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px', padding: '11px 12px', color: 'var(--text)', fontSize: '14px' }} />
          <button type="submit" disabled={submitting} style={{ background: 'var(--amber)', color: '#14120f', border: 'none', borderRadius: '6px', padding: '0 18px', fontWeight: 600, fontSize: '14px', cursor: 'pointer' }}>
            Create
          </button>
        </form>

        {tables.length === 0 ? (
          <div style={{ border: '1px dashed var(--border)', borderRadius: '8px', padding: '32px 20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px', fontFamily: 'var(--font-mono)' }}>
            No tables yet. Create one above to define its fields and start adding records.
          </div>
        ) : (
          <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {tables.map((t) => (
              <li key={t.id} style={{ marginBottom: '6px' }}>
                <a href={`/tables/${t.id}`} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '14px', background: 'var(--surface)', border: '1px solid var(--border)',
                  borderRadius: '6px', textDecoration: 'none', color: 'var(--text)', fontSize: '14px',
                }}>
                  {t.name}
                  <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>open →</span>
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  )
}
