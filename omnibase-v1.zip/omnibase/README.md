# OmniBase v1

The wedge: a no-code schema builder + record grid. Create a table, define fields
(text/number/boolean/date), add records, edit inline — no SQL.

## Architecture
Instead of running raw `CREATE TABLE` DDL per user action (a real security/ops risk
for a multi-tenant product), OmniBase v1 stores everything in a flexible meta-schema:
- `ob_tables` — every table a user defines
- `ob_fields` — the columns for that table (name + type)
- `ob_records` — the row data, stored as JSONB keyed by field name

This is the same pattern Airtable/NocoDB/Baserow use under the hood for v1-style
flexibility. Instant REST/GraphQL exposure and the GitHub/Vercel/Netlify/Stripe
integration hub are the next layers to add on top of this core.

## Run locally
1. `npm install`
2. Rename `.env.local.example` to `.env.local` (already filled in with your Supabase project)
3. `npm run dev`

## Not yet built
- Instant REST/GraphQL API generation per table
- GitHub/Vercel/Netlify/Stripe one-click integration hub
- Custom views (filters, sorts, kanban/calendar views)
