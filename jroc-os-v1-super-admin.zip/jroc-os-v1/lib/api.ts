import { createClient } from './supabase-browser';

async function authHeaders() {
  const supabase = createClient();
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error('You must be logged in.');
  return {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

function functionUrl(name: string) {
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!base) throw new Error('Missing NEXT_PUBLIC_SUPABASE_URL');
  return `${base}/functions/v1/${name}`;
}

export async function aiChat(input: { organization_id: string; agent_id?: string; conversation_id?: string; message: string }) {
  const res = await fetch(functionUrl('ai-chat'), {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify(input),
  });
  const json = await res.json();
  if (!res.ok || !json.success) throw new Error(json.error?.message || 'AI request failed');
  return json.data as { conversation_id: string; message: string; tokens_used: number };
}

export async function startCheckout(input: { checkout_type: 'marketplace' | 'subscription'; product_id?: string; plan?: string }) {
  const res = await fetch(functionUrl('stripe-checkout'), {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify(input),
  });
  const json = await res.json();
  if (!res.ok || !json.success) throw new Error(json.error?.message || 'Checkout failed');
  return json.data as { checkout_url: string };
}

export async function marketplaceDownload(product_id: string) {
  const res = await fetch(functionUrl('marketplace-download'), {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify({ product_id }),
  });
  const json = await res.json();
  if (!res.ok || !json.success) throw new Error(json.error?.message || 'Download failed');
  return json.data as { download_url: string; expires_in_seconds: number; title: string };
}
