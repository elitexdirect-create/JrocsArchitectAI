'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';

type Agent = { id: string; name: string; role: string; description: string | null; active: boolean; system_prompt: string };

export default function AgentsPage() {
  const supabase = createClient();
  const [organizationId, setOrganizationId] = useState('');
  const [agents, setAgents] = useState<Agent[]>([]);
  const [name, setName] = useState('AI COO');
  const [role, setRole] = useState('Operations and execution');
  const [description, setDescription] = useState('Runs planning, prioritization, execution, and accountability.');
  const [prompt, setPrompt] = useState('You are the J-ROC AI COO. Turn strategy into weekly execution plans, SOPs, priorities, and owner-based action steps.');
  const [error, setError] = useState('');

  async function load() {
    const { data: member } = await supabase.from('organization_members').select('organization_id').limit(1).maybeSingle();
    if (!member?.organization_id) return;
    setOrganizationId(member.organization_id);
    const { data } = await supabase.from('ai_agents').select('id,name,role,description,active,system_prompt').eq('organization_id', member.organization_id).order('created_at', { ascending: false });
    setAgents(data || []);
  }
  useEffect(() => { load(); }, []);

  async function createAgent(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from('ai_agents').insert({ organization_id: organizationId, name, role, description, system_prompt: prompt, created_by: userData.user?.id });
    if (error) return setError(error.message);
    await load();
  }

  async function toggleAgent(agent: Agent) {
    await supabase.from('ai_agents').update({ active: !agent.active }).eq('id', agent.id);
    await load();
  }

  return (
    <>
      <PageHeader eyebrow="AI Workforce" title="Agent Command Center" subtitle="Create and manage AI CEO, COO, CFO, marketing, sales, operations, and support agents." />
      <section className="grid grid-2">
        <form className="card form" onSubmit={createAgent}>
          <h3>Create AI Agent</h3>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={name} onChange={e => setName(e.target.value)} required />
          <input className="input" value={role} onChange={e => setRole(e.target.value)} required />
          <textarea className="textarea" value={description} onChange={e => setDescription(e.target.value)} />
          <textarea className="textarea" value={prompt} onChange={e => setPrompt(e.target.value)} required />
          <button className="btn">Create Agent</button>
        </form>
        <div className="grid">
          {agents.length === 0 && <div className="card">No AI agents yet.</div>}
          {agents.map(a => <div className="card" key={a.id}><span className="badge">{a.active ? 'active' : 'inactive'}</span><h3>{a.name}</h3><p>{a.role}</p><p>{a.description}</p><button className="btn secondary" onClick={() => toggleAgent(a)}>{a.active ? 'Deactivate' : 'Activate'}</button></div>)}
        </div>
      </section>
    </>
  );
}
