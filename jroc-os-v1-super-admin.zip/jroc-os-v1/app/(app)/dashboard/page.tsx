import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-server';

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: orgs } = await supabase.from('organization_members').select('organization_id, organizations(name)').limit(1);
  const organizationId = orgs?.[0]?.organization_id;
  const [{ count: projects }, { count: tasks }, { count: assets }, { count: sops }] = await Promise.all([
    organizationId ? supabase.from('projects').select('*', { count: 'exact', head: true }).eq('organization_id', organizationId) : { count: 0 },
    organizationId ? supabase.from('tasks').select('*', { count: 'exact', head: true }).eq('organization_id', organizationId) : { count: 0 },
    organizationId ? supabase.from('knowledge_assets').select('*', { count: 'exact', head: true }).eq('organization_id', organizationId) : { count: 0 },
    organizationId ? supabase.from('sops').select('*', { count: 'exact', head: true }).eq('organization_id', organizationId) : { count: 0 },
  ] as any);

  return (
    <>
      <PageHeader eyebrow="Command Center" title="J-ROC OS Dashboard" subtitle="Your active operating system for vision, execution, intelligence, and scale." />
      {!organizationId && <div className="alert">No organization found. Create one during signup or insert an organization record.</div>}
      <section className="grid grid-3">
        <div className="card"><span className="badge">Projects</span><div className="metric">{projects ?? 0}</div><p>Active execution containers.</p></div>
        <div className="card"><span className="badge">Tasks</span><div className="metric">{tasks ?? 0}</div><p>Open operational actions.</p></div>
        <div className="card"><span className="badge">Brain Assets</span><div className="metric">{assets ?? 0}</div><p>Knowledge vault items.</p></div>
        <div className="card"><span className="badge">SOPs</span><div className="metric">{sops ?? 0}</div><p>Documented systems.</p></div>
        <div className="card"><h3>Weekly COO Directive</h3><p>Use AI Commander to define this week’s highest ROI target, blockers, owner, and next 3 actions.</p></div>
        <div className="card"><h3>Growth Formula</h3><p>Vision + Systems + AI + Execution = Scalable Growth.</p></div>
      </section>
    </>
  );
}
