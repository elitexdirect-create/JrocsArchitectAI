'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';

type Sop = { id: string; title: string; department: string | null; status: string; content: string };

export default function SopsPage() {
  const supabase = createClient();
  const [organizationId, setOrganizationId] = useState('');
  const [sops, setSops] = useState<Sop[]>([]);
  const [title, setTitle] = useState('Client Onboarding SOP');
  const [department, setDepartment] = useState('Operations');
  const [content, setContent] = useState('1. Intake client. 2. Create project. 3. Deploy growth system.');
  const [error, setError] = useState('');

  async function load() {
    const { data: member } = await supabase.from('organization_members').select('organization_id').limit(1).maybeSingle();
    if (!member?.organization_id) return;
    setOrganizationId(member.organization_id);
    const { data } = await supabase.from('sops').select('id,title,department,status,content').eq('organization_id', member.organization_id).order('created_at', { ascending: false });
    setSops(data || []);
  }
  useEffect(() => { load(); }, []);

  async function createSop(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from('sops').insert({ organization_id: organizationId, title, department, content, created_by: userData.user?.id });
    if (error) return setError(error.message);
    await load();
  }

  return (
    <>
      <PageHeader eyebrow="Systems" title="SOP Library" subtitle="Document repeatable systems so the business can scale without chaos." />
      <section className="grid grid-2">
        <form className="card form" onSubmit={createSop}>
          <h3>Create SOP</h3>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={title} onChange={e => setTitle(e.target.value)} required />
          <input className="input" value={department} onChange={e => setDepartment(e.target.value)} />
          <textarea className="textarea" value={content} onChange={e => setContent(e.target.value)} required />
          <button className="btn">Save SOP</button>
        </form>
        <div className="grid">
          {sops.length === 0 && <div className="card">No SOPs yet.</div>}
          {sops.map(s => <div className="card" key={s.id}><span className="badge">{s.department || 'General'} / {s.status}</span><h3>{s.title}</h3><p>{s.content}</p></div>)}
        </div>
      </section>
    </>
  );
}
