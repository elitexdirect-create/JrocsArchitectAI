'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';

type Project = { id: string; title: string; status: string; priority: string; description: string | null };

export default function ProjectsPage() {
  const supabase = createClient();
  const [organizationId, setOrganizationId] = useState('');
  const [projects, setProjects] = useState<Project[]>([]);
  const [title, setTitle] = useState('Launch J-ROC OS MVP');
  const [description, setDescription] = useState('Build the first operating system release.');
  const [error, setError] = useState('');

  async function load() {
    const { data: member } = await supabase.from('organization_members').select('organization_id').limit(1).maybeSingle();
    if (!member?.organization_id) return;
    setOrganizationId(member.organization_id);
    const { data } = await supabase.from('projects').select('id,title,status,priority,description').eq('organization_id', member.organization_id).order('created_at', { ascending: false });
    setProjects(data || []);
  }
  useEffect(() => { load(); }, []);

  async function createProject(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from('projects').insert({ organization_id: organizationId, title, description, created_by: userData.user?.id });
    if (error) return setError(error.message);
    await load();
  }

  return (
    <>
      <PageHeader eyebrow="Execution" title="Projects" subtitle="Turn vision into execution containers with owners, priorities, tasks, and outcomes." />
      <section className="grid grid-2">
        <form className="card form" onSubmit={createProject}>
          <h3>Create Project</h3>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={title} onChange={e => setTitle(e.target.value)} required />
          <textarea className="textarea" value={description} onChange={e => setDescription(e.target.value)} />
          <button className="btn">Create Project</button>
        </form>
        <div className="grid">
          {projects.length === 0 && <div className="card">No projects yet.</div>}
          {projects.map(p => <div className="card" key={p.id}><span className="badge">{p.priority} / {p.status}</span><h3>{p.title}</h3><p>{p.description}</p></div>)}
        </div>
      </section>
    </>
  );
}
