'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';
import { aiChat } from '@/lib/api';

type Msg = { role: 'user' | 'assistant'; content: string };

export default function CommanderPage() {
  const supabase = createClient();
  const [organizationId, setOrganizationId] = useState('');
  const [conversationId, setConversationId] = useState<string | undefined>();
  const [message, setMessage] = useState('What should I focus on this week?');
  const [messages, setMessages] = useState<Msg[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from('organization_members').select('organization_id').limit(1).then(({ data }) => {
      if (data?.[0]?.organization_id) setOrganizationId(data[0].organization_id);
    });
  }, []);

  async function send() {
    if (!organizationId) return setError('No organization found.');
    if (!message.trim()) return;
    const userMsg = message;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setMessage('');
    setLoading(true);
    setError('');
    try {
      const data = await aiChat({ organization_id: organizationId, conversation_id: conversationId, message: userMsg });
      setConversationId(data.conversation_id);
      setMessages(prev => [...prev, { role: 'assistant', content: data.message }]);
    } catch (e: any) {
      setError(e.message || 'AI Commander is unavailable.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <PageHeader eyebrow="AI Commander" title="Strategic AI COO" subtitle="Ask J-ROC to plan, prioritize, execute, and scale your business growth systems." />
      <section className="card chat">
        <div className="messages">
          {error && <div className="alert">{error}</div>}
          {messages.length === 0 && <div className="message">Start with: “What should I focus on this week?”</div>}
          {messages.map((m, i) => <div key={i} className={`message ${m.role === 'user' ? 'user' : ''}`}>{m.content}</div>)}
          {loading && <div className="message">J-ROC AI Commander is thinking...</div>}
        </div>
        <div className="row" style={{ marginTop: 16 }}>
          <textarea className="textarea" value={message} onChange={e => setMessage(e.target.value)} />
          <button className="btn" onClick={send} disabled={loading}>Send</button>
        </div>
      </section>
    </>
  );
}
