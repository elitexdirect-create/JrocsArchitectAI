'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';
import { startCheckout, marketplaceDownload } from '@/lib/api';

type Product = { id: string; title: string; description: string | null; price: number; product_type: string };

export default function MarketplacePage() {
  const supabase = createClient();
  const [products, setProducts] = useState<Product[]>([]);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    supabase.from('marketplace_products').select('id,title,description,price,product_type').eq('active', true).then(({ data }) => setProducts(data || []));
  }, []);

  async function buy(product_id: string) {
    setError('');
    try {
      const data = await startCheckout({ checkout_type: 'marketplace', product_id });
      window.location.href = data.checkout_url;
    } catch (e: any) { setError(e.message); }
  }

  async function download(product_id: string) {
    setError(''); setNotice('');
    try {
      const data = await marketplaceDownload(product_id);
      setNotice(`Download ready for ${data.title}. Link expires in ${data.expires_in_seconds} seconds.`);
      window.open(data.download_url, '_blank');
    } catch (e: any) { setError(e.message); }
  }

  return (
    <>
      <PageHeader eyebrow="Marketplace" title="J-ROC Growth Assets" subtitle="Sell and deliver AI agents, prompt packs, playbooks, templates, dashboards, and SOP packs." />
      {error && <div className="alert">{error}</div>}
      {notice && <div className="alert success">{notice}</div>}
      <section className="grid grid-3">
        {products.length === 0 && <div className="card">No marketplace products yet. Seed products are included in the SQL migration.</div>}
        {products.map(p => <div className="card" key={p.id}><span className="badge">{p.product_type}</span><h3>{p.title}</h3><p>{p.description}</p><div className="metric">${p.price}</div><div className="row"><button className="btn" onClick={() => buy(p.id)}>Buy</button><button className="btn secondary" onClick={() => download(p.id)}>Download</button></div></div>)}
      </section>
    </>
  );
}
