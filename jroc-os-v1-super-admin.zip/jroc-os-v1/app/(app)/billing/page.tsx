'use client';

import { useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { startCheckout } from '@/lib/api';

const plans = [
  { id: 'growth', name: 'Growth', price: '$97/mo', text: 'For founders building execution systems.' },
  { id: 'pro', name: 'Pro', price: '$297/mo', text: 'For teams scaling AI systems and marketplace assets.' },
  { id: 'enterprise', name: 'Enterprise', price: 'Custom', text: 'For advanced multi-team operating systems.' },
];

export default function BillingPage() {
  const [error, setError] = useState('');
  async function subscribe(plan: string) {
    setError('');
    try {
      const data = await startCheckout({ checkout_type: 'subscription', plan });
      window.location.href = data.checkout_url;
    } catch (e: any) { setError(e.message); }
  }
  return (
    <>
      <PageHeader eyebrow="Billing" title="Upgrade J-ROC OS" subtitle="Enable higher AI usage, team workflows, training, marketplace delivery, and operational scale." />
      {error && <div className="alert">{error}</div>}
      <section className="grid grid-3">
        {plans.map(p => <div className="card" key={p.id}><span className="badge">{p.name}</span><h3>{p.price}</h3><p>{p.text}</p><button className="btn" onClick={() => subscribe(p.id)}>Start {p.name}</button></div>)}
      </section>
    </>
  );
}
