'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';

type Asset = { id: string; title: string; category: string | null; asset_type: string; content: string | null };

export default function BrainPage() {
  const supabase = createClient();
  const [organizationId, setOrganizationId] = useState('');
  const [assets, setAssets] = useState<Asset[]>([]);
  const [title, setTitle] = useState('J-ROC Methodology');
  const [category, setCategory] = useState('Strategy');
  const [content, setContent] = useState('Discover, Design, Deploy, Optimize, Scale.');
  const [error, setError] = useState('');

  async function load() {
    const { data: member } = await supabase.from('organization_members').select('organization_id').limit(1).maybeSingle();
    if (!member?.organization_id) return;
    setOrganizationId(member.organization_id);
    const { data } = await supabase.from('knowledge_assets').select('id,title,category,asset_type,content').eq('organization_id', member.organization_id).order('created_at', { ascending: false });
    setAssets(data || []);
  }
  useEffect(() => { load(); }, []);

  async function createAsset(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from('knowledge_assets').insert({ organization_id: organizationId, title, category, content, asset_type: 'framework', created_by: userData.user?.id });
    if (error) return setError(error.message);
    await load();
  }

  return (
    <>
      <PageHeader eyebrow="Brain Vault" title="J-ROC Knowledge Brain" subtitle="Store frameworks, prompts, playbooks, templates, and operating knowledge." />
      <section className="grid grid-2">
        <form className="card form" onSubmit={createAsset}>
          <h3>Create Brain Asset</h3>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={title} onChange={e => setTitle(e.target.value)} required />
          <input className="input" value={category} onChange={e => setCategory(e.target.value)} />
          <textarea className="textarea" value={content} onChange={e => setContent(e.target.value)} />
          <button className="btn">Save Asset</button>
        </form>
        <div className="grid">
          {assets.length === 0 && <div className="card">No brain assets yet.</div>}
          {assets.map(a => <div className="card" key={a.id}><span className="badge">{a.category || a.asset_type}</span><h3>{a.title}</h3><p>{a.content}</p></div>)}
        </div>
      </section>
    </>
  );
}
