'use client';

import { useEffect, useState } from 'react';
import PageHeader from '@/components/PageHeader';
import { createClient } from '@/lib/supabase-browser';

type Product = { id: string; title: string; description: string | null; product_type: string; price: number; active: boolean; asset_storage_path: string | null };
type Org = { id: string; name: string; owner_id: string; created_at: string };
type Profile = { id: string; email: string; full_name: string | null; plan: string };

export default function AdminPage() {
  const supabase = createClient();
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [title, setTitle] = useState('J-ROC Growth Dashboard Template');
  const [description, setDescription] = useState('A dashboard template for tracking growth, execution, and KPIs.');
  const [productType, setProductType] = useState('dashboard');
  const [price, setPrice] = useState('97');
  const [assetPath, setAssetPath] = useState('');
  const [error, setError] = useState('');

  async function load() {
    setError('');
    const { data: superRows } = await supabase.from('super_admins').select('id').eq('active', true).limit(1);
    const superAccess = Boolean(superRows && superRows.length > 0);
    setIsSuperAdmin(superAccess);

    const { data: productRows } = await supabase.from('marketplace_products').select('id,title,description,product_type,price,active,asset_storage_path').order('created_at', { ascending: false });
    setProducts(productRows || []);

    if (superAccess) {
      const [{ data: orgRows }, { data: profileRows }] = await Promise.all([
        supabase.from('organizations').select('id,name,owner_id,created_at').order('created_at', { ascending: false }).limit(50),
        supabase.from('profiles').select('id,email,full_name,plan').order('created_at', { ascending: false }).limit(50),
      ]);
      setOrgs(orgRows || []);
      setProfiles(profileRows || []);
    }
  }

  useEffect(() => { load(); }, []);

  async function audit(action: string, target_type: string, target_id?: string, metadata: Record<string, unknown> = {}) {
    const { data: userData } = await supabase.auth.getUser();
    await supabase.from('super_admin_audit_events').insert({ actor_user_id: userData.user?.id, action, target_type, target_id, metadata });
  }

  async function createProduct(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { data: userData } = await supabase.auth.getUser();
    const { data, error } = await supabase.from('marketplace_products').insert({
      title,
      description,
      product_type: productType,
      price: Number(price),
      currency: 'usd',
      active: true,
      asset_storage_path: assetPath || null,
      created_by: userData.user?.id,
    }).select('id').single();
    if (error) return setError(error.message);
    if (isSuperAdmin && data?.id) await audit('CREATE_PRODUCT', 'marketplace_product', data.id, { title, productType, price });
    await load();
  }

  async function toggleProduct(product: Product) {
    setError('');
    const { error } = await supabase.from('marketplace_products').update({ active: !product.active }).eq('id', product.id);
    if (error) return setError(error.message);
    if (isSuperAdmin) await audit(product.active ? 'DEACTIVATE_PRODUCT' : 'ACTIVATE_PRODUCT', 'marketplace_product', product.id);
    await load();
  }

  async function changePlan(profile: Profile, plan: string) {
    setError('');
    const { error } = await supabase.from('profiles').update({ plan }).eq('id', profile.id);
    if (error) return setError(error.message);
    await audit('CHANGE_USER_PLAN', 'profile', profile.id, { from: profile.plan, to: plan });
    await load();
  }

  return (
    <>
      <PageHeader eyebrow="Admin God Mode" title="J-ROC Platform Command" subtitle="Super Admin controls for platform operators. This mode uses explicit RLS policies and audit logging, not hidden security bypasses." />
      {!isSuperAdmin && <div className="alert">You are seeing standard admin mode. To enable Super God Mode, add your auth user ID to public.super_admins using the bootstrap SQL in migration 0002.</div>}
      {isSuperAdmin && <div className="alert success">Super God Mode active. Use carefully. Sensitive actions should be audited.</div>}
      {error && <div className="alert">{error}</div>}

      <section className="grid grid-2">
        <form className="card form" onSubmit={createProduct}>
          <h3>Create Marketplace Product</h3>
          <input className="input" value={title} onChange={e => setTitle(e.target.value)} required />
          <textarea className="textarea" value={description} onChange={e => setDescription(e.target.value)} />
          <select className="select" value={productType} onChange={e => setProductType(e.target.value)}>
            <option value="prompt_pack">Prompt Pack</option>
            <option value="agent">Agent</option>
            <option value="template">Template</option>
            <option value="sop_pack">SOP Pack</option>
            <option value="dashboard">Dashboard</option>
            <option value="course">Course</option>
            <option value="playbook">Playbook</option>
            <option value="automation">Automation</option>
          </select>
          <input className="input" value={price} onChange={e => setPrice(e.target.value)} type="number" min="0" step="1" />
          <input className="input" value={assetPath} onChange={e => setAssetPath(e.target.value)} placeholder="Private storage path, e.g. templates/file.zip" />
          <button className="btn">Create Product</button>
        </form>

        <div className="grid">
          {products.length === 0 && <div className="card">No products yet.</div>}
          {products.map(p => <div className="card" key={p.id}><span className="badge">{p.product_type} / {p.active ? 'active' : 'inactive'}</span><h3>{p.title}</h3><p>{p.description}</p><p>Asset: {p.asset_storage_path || 'No file attached'}</p><div className="row"><strong>${p.price}</strong><button className="btn secondary" onClick={() => toggleProduct(p)}>{p.active ? 'Deactivate' : 'Activate'}</button></div></div>)}
        </div>
      </section>

      {isSuperAdmin && <section className="grid grid-2" style={{ marginTop: 18 }}>
        <div className="card">
          <span className="badge">Organizations</span>
          <h3>Platform Organizations</h3>
          {orgs.length === 0 && <p>No organizations found.</p>}
          {orgs.map(o => <p key={o.id}><strong>{o.name}</strong><br /><span style={{ color: 'var(--muted)' }}>{o.id}</span></p>)}
        </div>
        <div className="card">
          <span className="badge">Users</span>
          <h3>User Plan Controls</h3>
          {profiles.length === 0 && <p>No profiles found.</p>}
          {profiles.map(p => <div key={p.id} style={{ borderTop: '1px solid var(--line)', paddingTop: 12, marginTop: 12 }}>
            <strong>{p.email}</strong><br />
            <span style={{ color: 'var(--muted)' }}>{p.full_name || 'No name'} / {p.plan}</span>
            <div className="row" style={{ marginTop: 8 }}>
              {['free','growth','pro','enterprise'].map(plan => <button key={plan} className="btn secondary" onClick={() => changePlan(p, plan)}>{plan}</button>)}
            </div>
          </div>)}
        </div>
      </section>}
    </>
  );
}
