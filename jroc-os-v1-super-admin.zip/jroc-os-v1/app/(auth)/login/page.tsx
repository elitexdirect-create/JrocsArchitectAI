'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setError(error.message);
    router.push('/dashboard');
  }

  return (
    <main className="auth-wrap">
      <section className="card auth-card">
        <span className="badge">J-ROC Login</span>
        <h1 className="title">Enter Command Center</h1>
        <form className="form" onSubmit={onSubmit}>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" required />
          <input className="input" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
          <button className="btn" disabled={loading}>{loading ? 'Signing in...' : 'Log In'}</button>
        </form>
        <p className="subtitle" style={{ marginTop: 16 }}>No account? <Link href="/signup">Create one</Link></p>
      </section>
    </main>
  );
}
