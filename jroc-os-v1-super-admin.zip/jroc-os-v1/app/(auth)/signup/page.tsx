'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();
  const [fullName, setFullName] = useState('');
  const [orgName, setOrgName] = useState('J-ROC Command Center');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
    if (error) { setLoading(false); return setError(error.message); }
    const user = data.user;
    if (user) {
      await supabase.from('organizations').insert({ name: orgName, owner_id: user.id });
    }
    setLoading(false);
    router.push('/dashboard');
  }

  return (
    <main className="auth-wrap">
      <section className="card auth-card">
        <span className="badge">Create J-ROC OS</span>
        <h1 className="title">Build Your Growth OS</h1>
        <form className="form" onSubmit={onSubmit}>
          {error && <div className="alert">{error}</div>}
          <input className="input" value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Full name" required />
          <input className="input" value={orgName} onChange={e => setOrgName(e.target.value)} placeholder="Organization name" required />
          <input className="input" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" required />
          <input className="input" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required minLength={8} />
          <button className="btn" disabled={loading}>{loading ? 'Creating...' : 'Create Account'}</button>
        </form>
        <p className="subtitle" style={{ marginTop: 16 }}>Already have an account? <Link href="/login">Log in</Link></p>
      </section>
    </main>
  );
}
