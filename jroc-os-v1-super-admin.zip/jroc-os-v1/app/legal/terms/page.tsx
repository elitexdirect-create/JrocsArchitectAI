export default function TermsPage() {
  return <main className="auth-wrap"><section className="card auth-card"><span className="badge">Legal</span><h1 className="title">Terms of Service</h1><p className="subtitle">Draft placeholder for launch review. Replace with attorney-reviewed terms before production launch.</p></section></main>;
}
