import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="auth-wrap">
      <section className="card auth-card">
        <span className="badge">J-ROC OS</span>
        <h1 className="title">Your Vision. My Execution.</h1>
        <p className="subtitle">The operating system for business growth, AI execution, systems, SOPs, marketplace assets, and strategy.</p>
        <div className="row" style={{ marginTop: 24 }}>
          <Link className="btn" href="/signup">Start Building</Link>
          <Link className="btn secondary" href="/login">Log In</Link>
        </div>
      </section>
    </main>
  );
}
