import { handleCors } from '../_shared/cors.ts';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import { getAuthenticatedUser, getSupabaseAdmin } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  const cors = handleCors(req); if (cors) return cors;
  if (req.method !== 'POST') return errorResponse('METHOD_NOT_ALLOWED', 'Only POST is allowed.', 405);
  try {
    const { user } = await getAuthenticatedUser(req); if (!user) return errorResponse('UNAUTHORIZED', 'You must be logged in.', 401);
    const { product_id } = await req.json(); if (!product_id) return errorResponse('VALIDATION_ERROR','product_id is required.',422);
    const supabase = getSupabaseAdmin();
    const { data: purchase } = await supabase.from('purchases').select('id').eq('product_id', product_id).eq('user_id', user.id).eq('status','completed').maybeSingle();
    if (!purchase) return errorResponse('PURCHASE_REQUIRED','Purchase required before download.',403);
    const { data: product } = await supabase.from('marketplace_products').select('title,asset_storage_path,active').eq('id', product_id).eq('active',true).maybeSingle();
    if (!product?.asset_storage_path) return errorResponse('ASSET_NOT_AVAILABLE','This product does not have a downloadable asset yet.',404);
    const { data, error } = await supabase.storage.from('marketplace-assets').createSignedUrl(product.asset_storage_path, 600);
    if (error || !data?.signedUrl) return errorResponse('SIGNED_URL_FAILED','Could not generate download link.',500,error);
    return jsonResponse({ success: true, data: { product_id, title: product.title, download_url: data.signedUrl, expires_in_seconds: 600 } });
  } catch (err) { return errorResponse('DOWNLOAD_FAILED','Could not generate marketplace download.',500,String(err)); }
});
