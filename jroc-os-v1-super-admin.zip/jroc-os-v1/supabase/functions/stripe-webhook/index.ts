import Stripe from 'npm:stripe@14';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import { getSupabaseAdmin } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return errorResponse('METHOD_NOT_ALLOWED', 'Only POST is allowed.', 405);
  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2023-10-16' });
  const sig = req.headers.get('stripe-signature'); if (!sig) return errorResponse('MISSING_SIGNATURE','Missing Stripe signature.',400);
  const body = await req.text(); let event: Stripe.Event;
  try { event = await stripe.webhooks.constructEventAsync(body, sig, Deno.env.get('STRIPE_WEBHOOK_SECRET')!); } catch (err) { return errorResponse('INVALID_SIGNATURE','Stripe webhook signature verification failed.',400,String(err)); }
  const supabase = getSupabaseAdmin();
  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.user_id;
      if (session.metadata?.checkout_type === 'marketplace') await supabase.from('purchases').update({ status: 'completed', stripe_payment_intent_id: typeof session.payment_intent === 'string' ? session.payment_intent : null }).eq('stripe_checkout_session_id', session.id).eq('user_id', userId);
      if (session.metadata?.checkout_type === 'subscription') { const plan = session.metadata?.plan || 'growth'; await supabase.from('subscriptions').upsert({ user_id: userId, stripe_customer_id: typeof session.customer === 'string' ? session.customer : null, stripe_subscription_id: typeof session.subscription === 'string' ? session.subscription : null, plan, status: 'active' }, { onConflict: 'stripe_subscription_id' }); await supabase.from('profiles').update({ plan }).eq('id', userId); }
    }
    if (event.type === 'customer.subscription.deleted') { const sub = event.data.object as Stripe.Subscription; await supabase.from('subscriptions').update({ status: 'canceled', cancel_at_period_end: true }).eq('stripe_subscription_id', sub.id); const userId = sub.metadata?.user_id; if (userId) await supabase.from('profiles').update({ plan: 'free' }).eq('id', userId); }
    return jsonResponse({ received: true });
  } catch (err) { return errorResponse('WEBHOOK_PROCESSING_FAILED','Webhook verified but processing failed.',500,String(err)); }
});
