import OpenAI from 'npm:openai@4';
import { handleCors } from '../_shared/cors.ts';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import { assertOrgMember, getAuthenticatedUser, getSupabaseAdmin } from '../_shared/auth.ts';
import { assertAiUsageAllowed } from '../_shared/usage.ts';

Deno.serve(async (req) => {
  const cors = handleCors(req); if (cors) return cors;
  if (req.method !== 'POST') return errorResponse('METHOD_NOT_ALLOWED', 'Only POST is allowed.', 405);
  try {
    const { user } = await getAuthenticatedUser(req); if (!user) return errorResponse('UNAUTHORIZED', 'You must be logged in.', 401);
    const { organization_id, agent_id, conversation_id, message } = await req.json();
    if (!organization_id || typeof message !== 'string' || message.length < 1 || message.length > 8000) return errorResponse('VALIDATION_ERROR', 'organization_id and message are required.', 422);
    const supabase = getSupabaseAdmin();
    const member = await assertOrgMember(supabase, organization_id, user.id); if (!member.allowed) return errorResponse('FORBIDDEN', 'No access to this organization.', 403);
    const usage = await assertAiUsageAllowed(supabase, organization_id); if (!usage.allowed) return errorResponse(usage.reason!, 'AI monthly usage limit reached.', 429);
    let prompt = 'You are J-ROC AI Commander. J-ROC = The Operating System for Business Growth. Tagline: Your Vision. My Execution. Act as a strategic AI COO. Be direct and execution-focused.';
    if (agent_id) { const { data: agent } = await supabase.from('ai_agents').select('system_prompt,active').eq('id', agent_id).eq('organization_id', organization_id).maybeSingle(); if (!agent?.active) return errorResponse('AGENT_NOT_FOUND','Agent not found.',404); prompt = agent.system_prompt; }
    let cid = conversation_id;
    if (!cid) { const { data: c, error } = await supabase.from('ai_conversations').insert({ organization_id, user_id: user.id, agent_id: agent_id || null, title: message.slice(0,80) }).select('id').single(); if (error) return errorResponse('CONVERSATION_CREATE_FAILED','Could not create conversation.',500,error); cid = c.id; }
    const { data: history } = await supabase.from('ai_messages').select('role,content').eq('conversation_id', cid).eq('organization_id', organization_id).order('created_at', { ascending: true }).limit(20);
    await supabase.from('ai_messages').insert({ conversation_id: cid, organization_id, role: 'user', content: message });
    const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY')! });
    const completion = await openai.chat.completions.create({ model: 'gpt-4.1-mini', temperature: 0.4, messages: [{ role: 'system', content: prompt }, ...(history || []).map((m: any) => ({ role: m.role, content: m.content })), { role: 'user', content: message }] });
    const assistant = completion.choices?.[0]?.message?.content || 'J-ROC AI Commander could not generate a response.';
    const tokens = completion.usage?.total_tokens || 0;
    await supabase.from('ai_messages').insert({ conversation_id: cid, organization_id, role: 'assistant', content: assistant, tokens_used: tokens });
    await supabase.from('ai_usage_events').insert({ organization_id, user_id: user.id, agent_id: agent_id || null, tokens_used: tokens });
    return jsonResponse({ success: true, data: { conversation_id: cid, message: assistant, tokens_used: tokens } });
  } catch (err) { return errorResponse('AI_CHAT_FAILED', 'J-ROC AI Commander is temporarily unavailable.', 500, String(err)); }
});
