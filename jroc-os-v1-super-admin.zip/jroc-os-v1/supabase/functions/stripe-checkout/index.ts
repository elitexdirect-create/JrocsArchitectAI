import Stripe from 'npm:stripe@14';
import { handleCors } from '../_shared/cors.ts';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import { getAuthenticatedUser, getSupabaseAdmin } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  const cors = handleCors(req); if (cors) return cors;
  if (req.method !== 'POST') return errorResponse('METHOD_NOT_ALLOWED', 'Only POST is allowed.', 405);
  try {
    const { user } = await getAuthenticatedUser(req); if (!user) return errorResponse('UNAUTHORIZED', 'You must be logged in.', 401);
    const { checkout_type, product_id, plan } = await req.json();
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2023-10-16' });
    const appUrl = Deno.env.get('APP_URL')!;
    const supabase = getSupabaseAdmin();
    const { data: profile } = await supabase.from('profiles').select('email,full_name').eq('id', user.id).maybeSingle();
    const customer = await stripe.customers.create({ email: profile?.email || user.email || undefined, name: profile?.full_name || undefined, metadata: { user_id: user.id } });

    if (checkout_type === 'marketplace') {
      const { data: product } = await supabase.from('marketplace_products').select('id,title,description,price,currency,active').eq('id', product_id).eq('active', true).maybeSingle();
      if (!product) return errorResponse('PRODUCT_NOT_FOUND', 'Marketplace product was not found.', 404);
      const session = await stripe.checkout.sessions.create({ mode: 'payment', customer: customer.id, payment_method_types: ['card'], line_items: [{ quantity: 1, price_data: { currency: product.currency || 'usd', unit_amount: Math.round(Number(product.price) * 100), product_data: { name: product.title, description: product.description || undefined } } }], success_url: `${appUrl}/marketplace?success=1`, cancel_url: `${appUrl}/marketplace?cancelled=1`, metadata: { checkout_type: 'marketplace', product_id: product.id, user_id: user.id } });
      await supabase.from('purchases').insert({ product_id: product.id, user_id: user.id, stripe_checkout_session_id: session.id, amount: product.price, currency: product.currency || 'usd', status: 'pending' });
      return jsonResponse({ success: true, data: { checkout_url: session.url } });
    }

    if (checkout_type === 'subscription') {
      if (!['growth','pro','enterprise'].includes(plan)) return errorResponse('VALIDATION_ERROR', 'Valid plan is required.', 422);
      const priceId = { growth: Deno.env.get('STRIPE_GROWTH_PRICE_ID'), pro: Deno.env.get('STRIPE_PRO_PRICE_ID'), enterprise: Deno.env.get('STRIPE_ENTERPRISE_PRICE_ID') }[plan as string];
      if (!priceId) return errorResponse('PRICE_NOT_CONFIGURED', 'Stripe price ID is missing.', 500);
      const session = await stripe.checkout.sessions.create({ mode: 'subscription', customer: customer.id, payment_method_types: ['card'], line_items: [{ price: priceId, quantity: 1 }], success_url: `${appUrl}/billing?success=1`, cancel_url: `${appUrl}/billing?cancelled=1`, metadata: { checkout_type: 'subscription', plan, user_id: user.id }, subscription_data: { metadata: { user_id: user.id, plan } } });
      return jsonResponse({ success: true, data: { checkout_url: session.url } });
    }

    return errorResponse('VALIDATION_ERROR', 'checkout_type must be marketplace or subscription.', 422);
  } catch (err) { return errorResponse('CHECKOUT_FAILED', 'Could not create Stripe checkout session.', 500, String(err)); }
});
