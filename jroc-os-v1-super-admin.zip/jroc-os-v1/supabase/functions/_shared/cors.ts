export const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature', 'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS' };
export function handleCors(req: Request) { return req.method === 'OPTIONS' ? new Response('ok', { headers: corsHeaders }) : null; }
