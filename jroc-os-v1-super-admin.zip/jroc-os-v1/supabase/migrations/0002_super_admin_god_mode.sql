
-- =========================================================
-- J-ROC OS SUPER ADMIN / GOD MODE MIGRATION
-- Version: 1.1
-- Purpose: Platform-level super admin access with explicit RLS support
-- =========================================================

-- Super admins are platform operators. This table should only be modified
-- by service-role migrations or trusted backend admin tooling.
create table if not exists public.super_admins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade unique,
  granted_by uuid references auth.users(id) on delete set null,
  reason text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.super_admins enable row level security;

-- Helper function. Security definer allows RLS policies to check super admin status.
create or replace function public.is_super_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.super_admins sa
    where sa.user_id = auth.uid()
      and sa.active = true
  );
$$;

-- Super admins can view super-admin records. Do not allow public self-promotion.
create policy if not exists "super_admins_select_super_admins"
on public.super_admins
for select
using (public.is_super_admin());

create policy if not exists "super_admins_insert_super_admins"
on public.super_admins
for insert
with check (public.is_super_admin());

create policy if not exists "super_admins_update_super_admins"
on public.super_admins
for update
using (public.is_super_admin())
with check (public.is_super_admin());

create policy if not exists "super_admins_delete_super_admins"
on public.super_admins
for delete
using (public.is_super_admin());

-- Updated role helpers include super admin override.
create or replace function public.is_org_member(org_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select public.is_super_admin()
  or exists (
    select 1
    from public.organization_members om
    where om.organization_id = org_id
      and om.user_id = auth.uid()
  );
$$;

create or replace function public.is_org_admin(org_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select public.is_super_admin()
  or exists (
    select 1
    from public.organization_members om
    where om.organization_id = org_id
      and om.user_id = auth.uid()
      and om.role in ('owner', 'admin')
  );
$$;

create or replace function public.is_org_owner(org_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select public.is_super_admin()
  or exists (
    select 1
    from public.organization_members om
    where om.organization_id = org_id
      and om.user_id = auth.uid()
      and om.role = 'owner'
  );
$$;

-- Platform admin audit helper table for sensitive operations.
create table if not exists public.super_admin_audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.super_admin_audit_events enable row level security;

create policy if not exists "super_admin_audit_select_super_admins"
on public.super_admin_audit_events
for select
using (public.is_super_admin());

create policy if not exists "super_admin_audit_insert_super_admins"
on public.super_admin_audit_events
for insert
with check (public.is_super_admin());

-- Super admin convenience read access for platform-wide tables not tied to organizations.
-- Marketplace products already have public read and creator write. Add platform override.
create policy if not exists "marketplace_products_super_admin_all"
on public.marketplace_products
for all
using (public.is_super_admin())
with check (public.is_super_admin());

create policy if not exists "courses_super_admin_all"
on public.courses
for all
using (public.is_super_admin())
with check (public.is_super_admin());

create policy if not exists "lessons_super_admin_all"
on public.lessons
for all
using (public.is_super_admin())
with check (public.is_super_admin());

create policy if not exists "subscriptions_super_admin_select"
on public.subscriptions
for select
using (public.is_super_admin());

create policy if not exists "purchases_super_admin_select"
on public.purchases
for select
using (public.is_super_admin());

create policy if not exists "profiles_super_admin_select"
on public.profiles
for select
using (public.is_super_admin());

create policy if not exists "profiles_super_admin_update"
on public.profiles
for update
using (public.is_super_admin())
with check (public.is_super_admin());

-- Indexes
create index if not exists idx_super_admins_user_id on public.super_admins(user_id);
create index if not exists idx_super_admin_audit_actor on public.super_admin_audit_events(actor_user_id);

-- IMPORTANT FIRST SUPER ADMIN BOOTSTRAP:
-- Run this manually with your real user ID in Supabase SQL editor using the service role context:
-- insert into public.super_admins (user_id, reason)
-- values ('YOUR_AUTH_USER_UUID_HERE', 'Initial J-ROC platform owner');
