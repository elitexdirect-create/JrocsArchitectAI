# J-ROC OS v1

J-ROC OS is the operating system for business growth.

## Stack
- Next.js App Router
- Supabase Auth, Postgres, RLS, Storage
- Supabase Edge Functions
- Stripe checkout and webhook functions
- OpenAI-ready AI Commander endpoint

## Setup
1. Create a Supabase project.
2. Run `supabase/migrations/0001_jroc_os.sql` in Supabase SQL editor.
3. Deploy Edge Functions in `supabase/functions`.
4. Copy `.env.example` to `.env.local` and set public keys.
5. Run `npm install` then `npm run dev`.

## Required Supabase Edge Function secrets
- SUPABASE_URL
- SUPABASE_ANON_KEY
- SUPABASE_SERVICE_ROLE_KEY
- OPENAI_API_KEY
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_GROWTH_PRICE_ID
- STRIPE_PRO_PRICE_ID
- STRIPE_ENTERPRISE_PRICE_ID
- APP_URL


## Super Admin God Mode
Run `supabase/migrations/0002_super_admin_god_mode.sql` after the base migration.
Then bootstrap the first super admin from Supabase SQL Editor using your real auth user UUID:

```sql
insert into public.super_admins (user_id, reason)
values ('YOUR_AUTH_USER_UUID_HERE', 'Initial J-ROC platform owner');
```

Super Admin access is controlled through explicit RLS helper functions and is audited through `super_admin_audit_events`.
