import Link from 'next/link';
import { createClient } from '@/lib/supabase-server';

const links = [
  ['Dashboard', '/dashboard'],
  ['AI Commander', '/commander'],
  ['Brain Vault', '/brain'],
  ['Projects', '/projects'],
  ['SOPs', '/sops'],
  ['AI Agents', '/agents'],
  ['KPIs', '/kpis'],
  ['Marketplace', '/marketplace'],
  ['Admin', '/admin'],
  ['Billing', '/billing'],
  ['Settings', '/settings'],
] as const;

export default async function AppShell({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div className="jroc-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">JR</div>
          <div>
            <h1>J-ROC OS</h1>
            <p>Your Vision. My Execution.</p>
          </div>
        </div>
        <nav className="nav">
          {links.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}
        </nav>
        <div style={{ marginTop: 28, color: 'var(--muted)', fontSize: 13 }}>
          Signed in as<br />{user?.email}
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
