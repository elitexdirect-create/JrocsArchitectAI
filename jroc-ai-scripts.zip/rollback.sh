#!/usr/bin/env bash
set -euo pipefail

PROVIDER="${1:-vercel}"
TARGET="${2:-previous}"
PROJECT_NAME="${3:-jroc-ai}"

log() { echo "[jroc/rollback] $1"; }
fail() { echo "[jroc/rollback][error] $1" >&2; exit 1; }

log "Rollback requested for $PROJECT_NAME on $PROVIDER to $TARGET"

case "$PROVIDER" in
  vercel)
    command -v vercel >/dev/null 2>&1 || fail "Vercel CLI is required."
    log "Listing deployments. Pick the deployment URL or id to promote."
    vercel ls
    log "To complete rollback, run: vercel promote <deployment-url-or-id>"
    ;;

  netlify)
    command -v netlify >/dev/null 2>&1 || fail "Netlify CLI is required."
    log "Listing deploys"
    netlify deploy:list
    log "To complete rollback, restore a previous deploy in Netlify UI or use Netlify API."
    ;;

  docker)
    IMAGE_TAG="${TARGET}"
    CONTAINER_NAME="${CONTAINER_NAME:-jroc-ai-web}"
    log "Rolling Docker container $CONTAINER_NAME to image tag $IMAGE_TAG"
    docker stop "$CONTAINER_NAME" || true
    docker rm "$CONTAINER_NAME" || true
    docker run -d --name "$CONTAINER_NAME" -p 3000:3000 "jroc-ai:$IMAGE_TAG"
    ;;

  railway)
    command -v railway >/dev/null 2>&1 || fail "Railway CLI is required."
    log "Railway rollback is usually handled in the Railway dashboard. Opening deployment list."
    railway status
    ;;

  database)
    MIGRATION_TARGET="${TARGET}"
    log "Database rollback requested to $MIGRATION_TARGET"
    log "Use with caution. Recommended: restore from backup or apply a verified down migration."
    ;;

  *)
    fail "Unknown rollback provider: $PROVIDER. Use vercel, netlify, docker, railway, or database."
    ;;
esac

log "Rollback helper complete"
