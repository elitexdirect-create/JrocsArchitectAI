#!/usr/bin/env bash
set -euo pipefail

APP_NAME="jroc-ai"
ENV_FILE=".env"
ENV_EXAMPLE=".env.example"
REQUIRED_CMDS=(node npm docker)
OPTIONAL_CMDS=(pnpm git)

log() { echo "[jroc/bootstrap] $1"; }
fail() { echo "[jroc/bootstrap][error] $1" >&2; exit 1; }

log "Starting bootstrap for $APP_NAME"

for cmd in "${REQUIRED_CMDS[@]}"; do
  command -v "$cmd" >/dev/null 2>&1 || fail "$cmd is required but not installed."
done

if ! command -v pnpm >/dev/null 2>&1; then
  log "pnpm not found. Enabling pnpm through Corepack..."
  corepack enable || fail "Could not enable Corepack. Install pnpm manually."
fi

if [ ! -f "$ENV_FILE" ] && [ -f "$ENV_EXAMPLE" ]; then
  log "Creating $ENV_FILE from $ENV_EXAMPLE"
  cp "$ENV_EXAMPLE" "$ENV_FILE"
fi

log "Installing dependencies"
pnpm install

if [ -f "docker-compose.yml" ]; then
  log "Starting Postgres and Redis with Docker Compose"
  docker compose up -d postgres redis
fi

if [ -f "prisma/schema.prisma" ]; then
  log "Generating Prisma client"
  pnpm exec prisma generate

  log "Pushing database schema"
  pnpm exec prisma db push

  if [ -f "prisma/seed.ts" ]; then
    log "Seeding database"
    pnpm exec tsx prisma/seed.ts
  fi
fi

if command -v git >/dev/null 2>&1 && [ ! -d ".git" ]; then
  log "Initializing Git repository"
  git init
  git add .
  git commit -m "Initial Jroc AI bootstrap" || true
fi

log "Bootstrap complete"
log "Run: pnpm dev"
