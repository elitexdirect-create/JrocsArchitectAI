#!/usr/bin/env bash
set -euo pipefail

ENVIRONMENT="${1:-production}"
PROVIDER="${2:-vercel}"
PROJECT_NAME="${3:-jroc-ai}"
BUILD_CMD="${BUILD_CMD:-pnpm build}"

log() { echo "[jroc/deploy] $1"; }
fail() { echo "[jroc/deploy][error] $1" >&2; exit 1; }

log "Deploying $PROJECT_NAME to $ENVIRONMENT using $PROVIDER"

command -v pnpm >/dev/null 2>&1 || fail "pnpm is required."

if [ ! -f ".env" ]; then
  fail ".env file missing. Copy .env.example to .env and configure secrets."
fi

log "Installing dependencies"
pnpm install

log "Running lint if available"
pnpm lint || log "Lint skipped or failed. Review before production."

log "Building application"
$BUILD_CMD

case "$PROVIDER" in
  vercel)
    command -v vercel >/dev/null 2>&1 || fail "Vercel CLI is not installed. Run: npm i -g vercel"
    log "Deploying with Vercel"
    if [ "$ENVIRONMENT" = "production" ]; then
      vercel deploy --prod
    else
      vercel deploy
    fi
    ;;

  netlify)
    command -v netlify >/dev/null 2>&1 || fail "Netlify CLI is not installed. Run: npm i -g netlify-cli"
    log "Deploying with Netlify"
    if [ "$ENVIRONMENT" = "production" ]; then
      netlify deploy --prod
    else
      netlify deploy
    fi
    ;;

  docker)
    IMAGE_NAME="${DOCKER_IMAGE:-jroc-ai:latest}"
    log "Building Docker image $IMAGE_NAME"
    docker build -f infrastructure/docker/Dockerfile.web -t "$IMAGE_NAME" .
    log "Docker image created: $IMAGE_NAME"
    ;;

  railway)
    command -v railway >/dev/null 2>&1 || fail "Railway CLI is not installed."
    log "Deploying with Railway"
    railway up
    ;;

  render)
    log "Render deploy should be connected to Git. Push your branch or call Render API here."
    ;;

  cloudflare)
    command -v wrangler >/dev/null 2>&1 || fail "Wrangler is not installed. Run: npm i -g wrangler"
    log "Deploying with Cloudflare Wrangler"
    wrangler pages deploy apps/web/.next
    ;;

  *)
    fail "Unknown provider: $PROVIDER. Use vercel, netlify, docker, railway, render, or cloudflare."
    ;;
esac

log "Deployment flow complete"
