# Jroc AI CLI Usage Examples

## Bootstrap local development
```bash
chmod +x scripts/bootstrap.sh
./scripts/bootstrap.sh
pnpm dev
```

## Deploy examples
```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh production vercel jroc-ai
./scripts/deploy.sh preview vercel jroc-ai
./scripts/deploy.sh production netlify jroc-ai
./scripts/deploy.sh production docker jroc-ai
./scripts/deploy.sh production railway jroc-ai
./scripts/deploy.sh production cloudflare jroc-ai
```

## Rollback examples
```bash
chmod +x scripts/rollback.sh
./scripts/rollback.sh vercel previous jroc-ai
./scripts/rollback.sh netlify previous jroc-ai
./scripts/rollback.sh docker stable jroc-ai
./scripts/rollback.sh railway previous jroc-ai
./scripts/rollback.sh database 2026_08_10_backup jroc-ai
```

## Jroc command examples
```bash
./scripts/jroc build crm-saas
./scripts/jroc deploy production
./scripts/jroc rollback latest
./scripts/jroc run-swarm all
./scripts/jroc create-avatar cto
./scripts/jroc command-center
```

## Suggested admin command-center prompts
```text
Build a CRM SaaS with Stripe billing and an admin dashboard.
Deploy Project Alpha to Vercel production.
Run all swarms on failed deployments and repair them.
Create a DevOps Commander avatar with voice and lip sync.
Show revenue, AI token usage, platform health, and user growth.
```
