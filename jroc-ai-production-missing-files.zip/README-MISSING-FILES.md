# Jroc AI Production Missing Files Pack

This pack fills in the missing production modules for the Jroc AI scaffold:

- Auth and RBAC
- API routes
- LLM provider adapter
- Billing and Stripe routes
- Deployment services
- Project workspace services
- Agent tools
- IDE components
- Memory service
- Avatar voice/lip-sync files
- Monitoring
- Email provider/templates
- Test configs

## How to apply

Copy these folders into the root of your Jroc AI repo:

```bash
cp -R apps packages services prisma infrastructure tests vitest.config.ts playwright.config.ts /path/to/jroc-ai/
```

Then install extra packages:

```bash
pnpm add next-auth openai @anthropic-ai/sdk stripe zod
pnpm add -D vitest @playwright/test
```

Then run:

```bash
pnpm install
pnpm exec prisma generate
pnpm exec prisma db push
pnpm dev
```

## Important

These are production-oriented starter implementations. Before accepting real customers, connect real credentials, finish provider-specific deployment code, add full error handling, harden RBAC, and replace placeholder legal/email copy.
