export function AvatarMeetingRoom() { return <div className='grid grid-cols-3 gap-4'><div>CTO</div><div>Designer</div><div>DevOps</div></div> }
