export async function register() { console.log('Jroc AI instrumentation registered') }
