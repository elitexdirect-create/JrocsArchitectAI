import { NextResponse } from 'next/server'
import { prisma } from '@/packages/database/src/prisma'
export async function GET() { return NextResponse.json(await prisma.user.findMany({ take: 100, orderBy: { createdAt: 'desc' } })) }
