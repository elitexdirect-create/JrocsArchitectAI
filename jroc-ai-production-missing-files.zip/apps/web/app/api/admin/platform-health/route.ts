import { NextResponse } from 'next/server'
export async function GET() { return NextResponse.json({ ok: true, web: 'online', api: 'online', workers: 'pending', checkedAt: new Date().toISOString() }) }
