import { NextResponse } from 'next/server'
import { rollbackDeployment } from '@/packages/deployment/src/rollback-service'
export async function POST(_: Request, { params }: any) { return NextResponse.json(await rollbackDeployment(params.id)) }
