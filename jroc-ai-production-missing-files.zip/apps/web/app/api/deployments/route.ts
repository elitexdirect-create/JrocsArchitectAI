import { NextResponse } from 'next/server'
import { deployProject } from '@/packages/deployment/src/deploy-service'
export async function POST(req: Request) { const body = await req.json(); return NextResponse.json(await deployProject(body)) }
