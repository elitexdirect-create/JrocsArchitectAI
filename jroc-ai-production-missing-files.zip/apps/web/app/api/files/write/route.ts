import { NextResponse } from 'next/server'
import { writeWorkspaceFile } from '@/packages/projects/src/workspace'
export async function POST(req: Request) { const body = await req.json(); return NextResponse.json(await writeWorkspaceFile(body.projectId, body.path, body.content)) }
