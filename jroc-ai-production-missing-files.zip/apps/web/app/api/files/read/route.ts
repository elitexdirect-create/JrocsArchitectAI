import { NextResponse } from 'next/server'
import { readWorkspaceFile } from '@/packages/projects/src/workspace'
export async function POST(req: Request) { const body = await req.json(); return NextResponse.json(await readWorkspaceFile(body.projectId, body.path)) }
