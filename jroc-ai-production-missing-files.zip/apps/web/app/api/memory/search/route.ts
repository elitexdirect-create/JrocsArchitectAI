import { NextResponse } from 'next/server'
import { searchMemory } from '@/packages/memory/src/search-memory'
export async function POST(req: Request) { const body = await req.json(); return NextResponse.json(await searchMemory(body.query, body.projectId)) }
