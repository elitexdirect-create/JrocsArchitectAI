import { NextResponse } from 'next/server'
import { stripe } from '@/packages/billing/src/stripe'
import { handleStripeWebhook } from '@/packages/billing/src/webhooks'
export async function POST(req: Request) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature') || ''
  const event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET || '')
  return NextResponse.json(await handleStripeWebhook(event))
}
