import { NextResponse } from 'next/server'
import { prisma } from '@/packages/database/src/prisma'
export async function GET() { return NextResponse.json(await prisma.project.findMany({ take: 50, orderBy: { createdAt: 'desc' } })) }
export async function POST(req: Request) { const body = await req.json(); const project = await prisma.project.create({ data: { name: body.name, description: body.description, ownerId: body.ownerId } }); return NextResponse.json(project) }
