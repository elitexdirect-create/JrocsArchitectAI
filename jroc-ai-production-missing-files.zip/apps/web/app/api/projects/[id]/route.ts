import { NextResponse } from 'next/server'
import { prisma } from '@/packages/database/src/prisma'
export async function GET(_: Request, { params }: any) { return NextResponse.json(await prisma.project.findUnique({ where: { id: params.id }, include: { deployments: true, versions: true } })) }
export async function PATCH(req: Request, { params }: any) { const body = await req.json(); return NextResponse.json(await prisma.project.update({ where: { id: params.id }, data: body })) }
export async function DELETE(_: Request, { params }: any) { return NextResponse.json(await prisma.project.update({ where: { id: params.id }, data: { status: 'ARCHIVED' } })) }
