import { NextResponse } from 'next/server'
import { textToSpeech } from '@/packages/voice/src/text-to-speech'
import { generateLipSync } from '@/packages/voice/src/lip-sync'
export async function POST(req: Request) { const { text } = await req.json(); const audio = await textToSpeech(text); const lipsync = await generateLipSync(audio.audioUrl); return NextResponse.json({ audio, lipsync }) }
