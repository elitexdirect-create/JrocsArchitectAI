import { NextResponse } from 'next/server'
import { createCustomerPortal } from '@/packages/billing/src/customer-portal'
export async function POST(req: Request) { const { customerId } = await req.json(); const session = await createCustomerPortal(customerId); return NextResponse.json({ url: session.url }) }
