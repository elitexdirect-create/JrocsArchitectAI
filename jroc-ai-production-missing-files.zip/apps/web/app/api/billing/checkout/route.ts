import { NextResponse } from 'next/server'
import { createCheckoutSession } from '@/packages/billing/src/checkout'
export async function POST(req: Request) { const body = await req.json(); const session = await createCheckoutSession(body); return NextResponse.json({ url: session.url }) }
