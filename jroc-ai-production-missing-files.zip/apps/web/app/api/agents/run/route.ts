import { NextResponse } from 'next/server'
import { executeCommand } from '@/packages/ai/src/command-executor'
export async function POST(req: Request) {
  const body = await req.json()
  const result = await executeCommand(body.prompt || body.command, body)
  return NextResponse.json({ ok: true, result })
}
