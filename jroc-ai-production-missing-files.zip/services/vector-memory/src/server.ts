import http from 'node:http'
http.createServer((_, res) => { res.setHeader('content-type','application/json'); res.end(JSON.stringify({ service: 'vector-memory', status: 'online' })) }).listen(4100)
