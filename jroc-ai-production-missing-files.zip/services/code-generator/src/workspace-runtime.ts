export async function startWorkspaceRuntime(projectId: string) { return { projectId, status: 'running' } }
