export async function startPreview(projectId: string) { return { projectId, url: `http://localhost:3001/preview/${projectId}` } }
