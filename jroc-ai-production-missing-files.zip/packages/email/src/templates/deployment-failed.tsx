export function DeploymentFailedEmail() { return '<h1>deployment-failed</h1>' }
