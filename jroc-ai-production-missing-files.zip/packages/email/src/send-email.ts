import type { EmailPayload } from './provider'
export async function sendEmail(payload: EmailPayload) { console.log('email queued', payload.subject); return { queued: true } }
