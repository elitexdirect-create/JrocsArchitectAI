import { stripe } from './stripe'
export async function createCustomerPortal(customer: string) {
  return stripe.billingPortal.sessions.create({ customer, return_url: `${process.env.NEXTAUTH_URL}/billing` })
}
