import { stripe } from './stripe'
export async function createCheckoutSession({ priceId, customerEmail }: { priceId: string; customerEmail: string }) {
  return stripe.checkout.sessions.create({ mode: 'subscription', customer_email: customerEmail, line_items: [{ price: priceId, quantity: 1 }], success_url: `${process.env.NEXTAUTH_URL}/billing?success=1`, cancel_url: `${process.env.NEXTAUTH_URL}/billing?canceled=1` })
}
