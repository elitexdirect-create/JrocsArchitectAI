export async function handleStripeWebhook(event: any) {
  switch (event.type) {
    case 'checkout.session.completed': return { handled: true, action: 'subscription_created' }
    case 'customer.subscription.updated': return { handled: true, action: 'subscription_updated' }
    case 'customer.subscription.deleted': return { handled: true, action: 'subscription_deleted' }
    default: return { handled: false }
  }
}
