export const plans = {
  FREE: { name: 'Free', price: 0, projects: 1 },
  BRONZE: { name: 'Bronze', price: 29, projects: 25 },
  SILVER: { name: 'Silver', price: 99, projects: 100 },
  GOLD: { name: 'Gold', price: 299, projects: Infinity },
  ENTERPRISE: { name: 'Enterprise', price: null, projects: Infinity }
}
