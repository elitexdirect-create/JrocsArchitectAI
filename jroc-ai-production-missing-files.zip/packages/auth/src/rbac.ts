export type Role = 'USER' | 'SUPPORT_ADMIN' | 'PLATFORM_ADMIN' | 'SUPER_ADMIN'
export const roleRank: Record<Role, number> = { USER: 0, SUPPORT_ADMIN: 1, PLATFORM_ADMIN: 2, SUPER_ADMIN: 3 }
export function hasRole(userRole: Role, required: Role) { return roleRank[userRole] >= roleRank[required] }
export function isSuperAdmin(user?: { role?: Role }) { return user?.role === 'SUPER_ADMIN' }
