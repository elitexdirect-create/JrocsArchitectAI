import { requireUser } from './require-user'
import { hasRole } from './rbac'
export async function requireAdmin() {
  const user = await requireUser()
  if (!hasRole(user.role, 'PLATFORM_ADMIN')) throw new Error('Admin access required')
  return user
}
