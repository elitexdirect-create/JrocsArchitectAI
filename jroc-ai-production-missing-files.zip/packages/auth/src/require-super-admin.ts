import { requireUser } from './require-user'
export async function requireSuperAdmin() {
  const user = await requireUser()
  if (user.role !== 'SUPER_ADMIN') throw new Error('Super Admin access required')
  return user
}
