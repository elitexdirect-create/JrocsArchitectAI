import { isSuperAdmin } from './rbac'
export type LimitKey = 'projects' | 'deployments' | 'aiTokens' | 'storageGb' | 'avatars' | 'swarmRuns'
export const limits: Record<string, Record<LimitKey, number>> = {
  FREE: { projects: 1, deployments: 1, aiTokens: 10000, storageGb: 1, avatars: 1, swarmRuns: 5 },
  BRONZE: { projects: 25, deployments: 10, aiTokens: 250000, storageGb: 25, avatars: 3, swarmRuns: 100 },
  SILVER: { projects: 100, deployments: 50, aiTokens: 1000000, storageGb: 100, avatars: 10, swarmRuns: 500 },
  GOLD: { projects: Infinity, deployments: Infinity, aiTokens: 5000000, storageGb: 500, avatars: 25, swarmRuns: 2000 },
  ENTERPRISE: { projects: Infinity, deployments: Infinity, aiTokens: Infinity, storageGb: Infinity, avatars: Infinity, swarmRuns: Infinity }
}
export function checkPlanLimit(user: any, key: LimitKey, current: number) {
  if (isSuperAdmin(user)) return true
  return current < limits[user.plan || 'FREE'][key]
}
