import { getServerSession } from 'next-auth'
import { authOptions } from './auth-options'
export async function requireUser() {
  const session = await getServerSession(authOptions)
  if (!session?.user) throw new Error('Unauthorized')
  return session.user as any
}
