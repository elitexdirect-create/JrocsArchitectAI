export function metric(name: string, value: number, tags: any = {}) { console.log({ name, value, tags }) }
