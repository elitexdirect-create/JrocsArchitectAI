export async function auditLog(event: any) { return { id: crypto.randomUUID(), ...event, createdAt: new Date().toISOString() } }
