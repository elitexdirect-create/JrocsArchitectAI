export function captureError(error: unknown, context?: any) { console.error('captured error', error, context) }
