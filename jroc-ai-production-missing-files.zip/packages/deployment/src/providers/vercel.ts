export async function deployToVercel(input: any) {
  return { provider: 'vercel', status: 'queued', input }
}
