export async function deployToCloudflare(input: any) {
  return { provider: 'cloudflare', status: 'queued', input }
}
