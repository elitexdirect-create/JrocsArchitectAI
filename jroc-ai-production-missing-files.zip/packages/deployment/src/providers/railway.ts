export async function deployToRailway(input: any) {
  return { provider: 'railway', status: 'queued', input }
}
