export async function deployToDocker(input: any) {
  return { provider: 'docker', status: 'queued', input }
}
