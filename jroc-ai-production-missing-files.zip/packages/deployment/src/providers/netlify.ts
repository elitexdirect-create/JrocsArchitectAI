export async function deployToNetlify(input: any) {
  return { provider: 'netlify', status: 'queued', input }
}
