export async function healthCheck(url: string) { const res = await fetch(url); return { url, ok: res.ok, status: res.status } }
