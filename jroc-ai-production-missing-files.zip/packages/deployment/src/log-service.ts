export async function getDeploymentLogs(deploymentId: string) { return { deploymentId, logs: [] } }
