export async function rollbackDeployment(deploymentId: string) { return { deploymentId, status: 'rollback_queued', createdAt: new Date().toISOString() } }
