import { upsertVector } from './vector-store'
export async function saveProjectMemory(projectId: string, content: string, metadata: any = {}) { return upsertVector({ id: crypto.randomUUID(), projectId, content, metadata }) }
