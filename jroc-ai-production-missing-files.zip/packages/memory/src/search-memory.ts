import { queryVector } from './vector-store'
export async function searchMemory(query: string, projectId?: string) { const results = await queryVector(query); return projectId ? results.filter((r: any) => r.projectId === projectId) : results }
