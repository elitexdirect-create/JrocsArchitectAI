const memory: any[] = []
export async function upsertVector(record: any) { memory.push(record); return record }
export async function queryVector(query: string) { return memory.filter((m) => JSON.stringify(m).toLowerCase().includes(query.toLowerCase())) }
