export async function createEmbedding(text: string) { return { text, vector: Array.from({ length: 10 }, (_, i) => i / 10) } }
