export async function createAvatarSession(agentId: string) { return { id: crypto.randomUUID(), agentId, status: 'active' } }
