export function AvatarRenderer({ name = 'Jroc AI' }: { name?: string }) { return <div className='rounded-3xl bg-slate-900 p-8 text-center'>🤖 {name}</div> }
