export async function runTests(input: any) {
  return { tool: 'run-tests', status: 'completed', input }
}
