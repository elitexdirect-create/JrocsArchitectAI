export async function createComponent(input: any) {
  return { tool: 'create-component', status: 'completed', input }
}
