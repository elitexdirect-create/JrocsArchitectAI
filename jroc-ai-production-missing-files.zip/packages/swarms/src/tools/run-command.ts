export async function runCommand(input: any) {
  return { tool: 'run-command', status: 'completed', input }
}
