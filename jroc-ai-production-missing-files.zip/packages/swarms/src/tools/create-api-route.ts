export async function createApiRoute(input: any) {
  return { tool: 'create-api-route', status: 'completed', input }
}
