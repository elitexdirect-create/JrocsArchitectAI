export async function securityScan(input: any) {
  return { tool: 'security-scan', status: 'completed', input }
}
