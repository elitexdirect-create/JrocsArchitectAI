export async function updatePrismaSchema(input: any) {
  return { tool: 'update-prisma-schema', status: 'completed', input }
}
