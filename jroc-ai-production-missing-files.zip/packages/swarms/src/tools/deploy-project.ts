export async function deployProject(input: any) {
  return { tool: 'deploy-project', status: 'completed', input }
}
