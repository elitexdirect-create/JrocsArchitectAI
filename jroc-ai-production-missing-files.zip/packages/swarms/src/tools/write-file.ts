export async function writeFile(input: any) {
  return { tool: 'write-file', status: 'completed', input }
}
