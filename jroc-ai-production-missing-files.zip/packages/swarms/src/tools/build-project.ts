export async function buildProject(input: any) {
  return { tool: 'build-project', status: 'completed', input }
}
