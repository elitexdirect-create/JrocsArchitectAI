export async function readFile(input: any) {
  return { tool: 'read-file', status: 'completed', input }
}
