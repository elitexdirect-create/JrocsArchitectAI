export async function createProject(input: any) {
  return { tool: 'create-project', status: 'completed', input }
}
