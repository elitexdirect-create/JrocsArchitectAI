export async function rollbackProject(input: any) {
  return { tool: 'rollback-project', status: 'completed', input }
}
