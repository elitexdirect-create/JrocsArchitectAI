export function parseCommand(command: string) {
  const text = command.toLowerCase()
  if (text.includes('deploy')) return { intent: 'deploy', agent: 'devops' }
  if (text.includes('rollback')) return { intent: 'rollback', agent: 'recovery' }
  if (text.includes('build') || text.includes('create')) return { intent: 'build', agent: 'cto' }
  if (text.includes('scan') || text.includes('security')) return { intent: 'security_scan', agent: 'security' }
  return { intent: 'analyze', agent: 'cto' }
}
