import { parseCommand } from './command-parser'
import { routeAICommand } from './orchestrator-adapter'
export async function executeCommand(command: string, context: any = {}) {
  const parsed = parseCommand(command)
  const result = await routeAICommand({ command, parsed, context })
  return { parsed, result }
}
