export async function routeAICommand(input: any) {
  return { accepted: true, assignedAgent: input.parsed?.agent || 'cto', status: 'queued', command: input.command }
}
