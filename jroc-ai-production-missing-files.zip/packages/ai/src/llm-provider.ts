import OpenAI from 'openai'
import Anthropic from '@anthropic-ai/sdk'

export type LLMProvider = 'openai' | 'anthropic'
export async function callLLM({ provider = 'openai', system, prompt, model }: { provider?: LLMProvider; system?: string; prompt: string; model?: string }) {
  if (provider === 'anthropic') {
    const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
    const msg = await anthropic.messages.create({ model: model || 'claude-opus-4.5', max_tokens: 4096, system, messages: [{ role: 'user', content: prompt }] })
    const part = msg.content[0]
    return part.type === 'text' ? part.text : ''
  }
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  const res = await openai.responses.create({ model: model || 'gpt-5.2', input: `${system || ''}\n\n${prompt}` })
  return res.output_text
}
