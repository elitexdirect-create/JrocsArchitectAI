export async function createProject(input: { name: string; ownerId: string; description?: string }) { return { id: crypto.randomUUID(), ...input, status: 'DRAFT' } }
