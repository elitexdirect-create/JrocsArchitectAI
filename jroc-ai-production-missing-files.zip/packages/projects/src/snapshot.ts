export async function createSnapshot(projectId: string, label = 'snapshot') { return { id: crypto.randomUUID(), projectId, label, createdAt: new Date().toISOString() } }
