import fs from 'node:fs/promises'
import path from 'node:path'
const root = process.env.WORKSPACE_ROOT || '.jroc-workspaces'
function safePath(projectId: string, filePath: string) { return path.join(root, projectId, filePath.replace(/\.\./g, '')) }
export async function writeWorkspaceFile(projectId: string, filePath: string, content: string) { const target = safePath(projectId, filePath); await fs.mkdir(path.dirname(target), { recursive: true }); await fs.writeFile(target, content); return { ok: true, path: filePath } }
export async function readWorkspaceFile(projectId: string, filePath: string) { const content = await fs.readFile(safePath(projectId, filePath), 'utf8'); return { path: filePath, content } }
