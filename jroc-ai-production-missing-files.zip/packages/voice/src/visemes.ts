export const visemes = ['A','E','I','O','U','M','F','rest']
