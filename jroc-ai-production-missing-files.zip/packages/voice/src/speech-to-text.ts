export async function speechToText(audio: ArrayBuffer) { return { text: 'transcribed voice command', bytes: audio.byteLength } }
