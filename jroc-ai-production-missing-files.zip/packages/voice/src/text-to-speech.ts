export async function textToSpeech(text: string) { return { audioUrl: '/api/mock/audio.mp3', text } }
