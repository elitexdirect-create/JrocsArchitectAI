export async function generateLipSync(audioUrl: string) { return [{ start: 0, end: 0.2, mouth: 'A', audioUrl }] }
