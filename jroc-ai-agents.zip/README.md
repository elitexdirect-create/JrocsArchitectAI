# Jroc AI Agents

Drop this folder into:

```text
packages/swarms/src/agents
```

## Agents included

- CTO Agent
- Architect Agent
- Frontend Agent
- Backend Agent
- Database Agent
- QA Agent
- Security Agent
- DevOps Agent
- Recovery Agent
- Product Manager Agent
- Marketing Agent
- Sales Agent
- Support Agent
- Finance Agent
- Avatar Agent

## Example

```ts
import { runAgentChain } from './agents'

const results = await runAgentChain('cto', {
  id: 'task_001',
  title: 'Build CRM SaaS',
  prompt: 'Build a CRM SaaS with Stripe billing and deployment automation.',
  priority: 'high'
})
```

## Production next steps

Connect each agent to:

- LLM provider routing
- Queue workers
- Database logging
- Project file system
- Git/version system
- Deployment engine
- Avatar/voice system
- Admin Command Center
