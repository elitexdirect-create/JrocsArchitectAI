export type AgentRole =
  | 'architect'
  | 'frontend'
  | 'backend'
  | 'database'
  | 'qa'
  | 'security'
  | 'devops'
  | 'recovery'
  | 'product'
  | 'marketing'
  | 'sales'
  | 'support'
  | 'finance'
  | 'avatar'
  | 'cto'

export type AgentTask = {
  id: string
  projectId?: string
  title: string
  prompt: string
  priority?: 'low' | 'normal' | 'high' | 'critical'
  context?: Record<string, unknown>
}

export type AgentResult = {
  agent: AgentRole
  taskId: string
  status: 'queued' | 'running' | 'completed' | 'failed'
  summary: string
  output: Record<string, unknown>
  nextAgents?: AgentRole[]
  createdAt: string
}

export interface JrocAgent {
  role: AgentRole
  name: string
  description: string
  capabilities: string[]
  run(task: AgentTask): Promise<AgentResult>
}
