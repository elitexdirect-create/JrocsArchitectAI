import { runAgentChain } from './registry'

async function main() {
  const results = await runAgentChain('cto', {
    id: 'task_001',
    title: 'Build CRM SaaS',
    prompt: 'Build a CRM SaaS with Stripe billing, admin dashboard, AI chat, deployment automation, and analytics.',
    priority: 'high',
    projectId: 'project_jroc_crm'
  })

  console.log(JSON.stringify(results, null, 2))
}

main().catch(console.error)
