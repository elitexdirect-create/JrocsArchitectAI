import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class SupportAgent extends BaseAgent {
  role = 'support' as const
  name = 'Support Agent'
  description = 'Creates help centers, ticket workflows, customer responses, and support automations.'
  capabilities = [
    'Help center',
    'Ticket triage',
    'Customer replies',
    'Knowledge base',
    'Support automations'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        supportPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['product']
    )
  }
}
