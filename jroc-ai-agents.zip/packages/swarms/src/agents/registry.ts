import type { AgentRole, AgentTask } from './types'
import { ArchitectAgent } from './architect-agent'
import { FrontendAgent } from './frontend-agent'
import { BackendAgent } from './backend-agent'
import { DatabaseAgent } from './database-agent'
import { QaAgent } from './qa-agent'
import { SecurityAgent } from './security-agent'
import { DevopsAgent } from './devops-agent'
import { RecoveryAgent } from './recovery-agent'
import { ProductAgent } from './product-agent'
import { MarketingAgent } from './marketing-agent'
import { SalesAgent } from './sales-agent'
import { SupportAgent } from './support-agent'
import { FinanceAgent } from './finance-agent'
import { AvatarAgent } from './avatar-agent'
import { CtoAgent } from './cto-agent'

export const agentRegistry = {
  architect: new ArchitectAgent(),
  frontend: new FrontendAgent(),
  backend: new BackendAgent(),
  database: new DatabaseAgent(),
  qa: new QaAgent(),
  security: new SecurityAgent(),
  devops: new DevopsAgent(),
  recovery: new RecoveryAgent(),
  product: new ProductAgent(),
  marketing: new MarketingAgent(),
  sales: new SalesAgent(),
  support: new SupportAgent(),
  finance: new FinanceAgent(),
  avatar: new AvatarAgent(),
  cto: new CtoAgent()
}

export async function runAgent(role: AgentRole, task: AgentTask) {
  const agent = agentRegistry[role]
  if (!agent) throw new Error(`Unknown agent: ${role}`)
  return agent.run(task)
}

export async function runAgentChain(startRole: AgentRole, task: AgentTask, maxDepth = 4) {
  const results = []
  const queue: AgentRole[] = [startRole]
  const visited = new Set<string>()

  while (queue.length && results.length < maxDepth) {
    const role = queue.shift()!
    if (visited.has(role)) continue
    visited.add(role)

    const result = await runAgent(role, task)
    results.push(result)

    for (const next of result.nextAgents || []) {
      if (!visited.has(next)) queue.push(next)
    }
  }

  return results
}
