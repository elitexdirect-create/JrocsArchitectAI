import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class SalesAgent extends BaseAgent {
  role = 'sales' as const
  name = 'Sales Agent'
  description = 'Builds sales funnels, pricing strategy, lead flows, CRM logic, and conversion plans.'
  capabilities = [
    'Funnels',
    'Pricing',
    'Lead capture',
    'CRM workflows',
    'Conversion strategy'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        salesPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['support']
    )
  }
}
