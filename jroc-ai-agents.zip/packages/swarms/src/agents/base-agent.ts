import type { AgentResult, AgentRole, AgentTask, JrocAgent } from './types'

export abstract class BaseAgent implements JrocAgent {
  abstract role: AgentRole
  abstract name: string
  abstract description: string
  abstract capabilities: string[]

  protected result(task: AgentTask, summary: string, output: Record<string, unknown>, nextAgents: AgentRole[] = []): AgentResult {
    return {
      agent: this.role,
      taskId: task.id,
      status: 'completed',
      summary,
      output,
      nextAgents,
      createdAt: new Date().toISOString()
    }
  }

  protected parsePrompt(task: AgentTask) {
    return {
      prompt: task.prompt,
      projectId: task.projectId,
      priority: task.priority || 'normal',
      context: task.context || {}
    }
  }

  abstract run(task: AgentTask): Promise<AgentResult>
}
