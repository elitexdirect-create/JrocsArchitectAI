import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class FrontendAgent extends BaseAgent {
  role = 'frontend' as const
  name = 'Frontend Agent'
  description = 'Builds pages, layouts, components, responsive UI, dashboards, and user-facing workflows.'
  capabilities = [
    'React components',
    'Next.js pages',
    'Responsive UI',
    'Dashboards',
    'Design systems'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        frontendPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['qa']
    )
  }
}
