import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class FinanceAgent extends BaseAgent {
  role = 'finance' as const
  name = 'Finance Agent'
  description = 'Analyzes cost, revenue, AI token spend, subscriptions, margins, and forecasting.'
  capabilities = [
    'Revenue analysis',
    'Cost tracking',
    'Forecasting',
    'Stripe reporting',
    'Margin analysis'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        financeReport: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['product']
    )
  }
}
