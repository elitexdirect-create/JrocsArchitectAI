import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class CtoAgent extends BaseAgent {
  role = 'cto' as const
  name = 'CTO Agent'
  description = 'Supervises all agents, makes architecture decisions, reviews strategy, and routes commands.'
  capabilities = [
    'Agent routing',
    'Architecture review',
    'Technical strategy',
    'Risk analysis',
    'Platform oversight'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        ctoDecision: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['architect', 'security', 'devops']
    )
  }
}
