import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class ArchitectAgent extends BaseAgent {
  role = 'architect' as const
  name = 'Architect Agent'
  description = 'Plans application architecture, framework choices, folder structure, modules, and technical decisions.'
  capabilities = [
    'System architecture',
    'Framework selection',
    'Folder structure',
    'Module planning',
    'Technical design'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        applicationPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['frontend', 'backend', 'database']
    )
  }
}
