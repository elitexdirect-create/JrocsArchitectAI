import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class SecurityAgent extends BaseAgent {
  role = 'security' as const
  name = 'Security Agent'
  description = 'Scans for vulnerabilities, secrets, weak permissions, unsafe dependencies, and policy risks.'
  capabilities = [
    'Dependency audit',
    'Secret scanning',
    'RBAC review',
    'Rate limit checks',
    'Security reports'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        securityReport: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['recovery']
    )
  }
}
