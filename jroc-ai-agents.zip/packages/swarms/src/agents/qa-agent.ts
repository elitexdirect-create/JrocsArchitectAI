import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class QaAgent extends BaseAgent {
  role = 'qa' as const
  name = 'QA Agent'
  description = 'Tests generated code, verifies workflows, finds bugs, and produces validation reports.'
  capabilities = [
    'Unit tests',
    'Integration tests',
    'E2E tests',
    'Bug reports',
    'Acceptance checks'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        qaReport: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['recovery']
    )
  }
}
