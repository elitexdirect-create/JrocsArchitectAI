import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class DatabaseAgent extends BaseAgent {
  role = 'database' as const
  name = 'Database Agent'
  description = 'Designs schemas, relations, migrations, indexes, seed data, and storage strategy.'
  capabilities = [
    'Prisma schema',
    'PostgreSQL models',
    'Indexes',
    'Migrations',
    'Seed data'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        databasePlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['backend', 'qa']
    )
  }
}
