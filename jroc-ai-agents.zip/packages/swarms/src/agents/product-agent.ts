import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class ProductAgent extends BaseAgent {
  role = 'product' as const
  name = 'Product Manager Agent'
  description = 'Turns ideas into PRDs, roadmaps, epics, user stories, and prioritization plans.'
  capabilities = [
    'PRDs',
    'Roadmaps',
    'Epics',
    'User stories',
    'Prioritization'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        productPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['architect']
    )
  }
}
