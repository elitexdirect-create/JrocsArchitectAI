import { BaseAgent } from './base-agent'
import type { AgentResult, AgentTask } from './types'

export class BackendAgent extends BaseAgent {
  role = 'backend' as const
  name = 'Backend Agent'
  description = 'Creates APIs, services, business logic, integrations, queues, and server-side workflows.'
  capabilities = [
    'API routes',
    'Services',
    'Business logic',
    'Integrations',
    'Background jobs'
  ]

  async run(task: AgentTask): Promise<AgentResult> {
    const input = this.parsePrompt(task)

    return this.result(
      task,
      `${this.name} completed task: ${task.title}`,
      {
        backendPlan: {
          prompt: input.prompt,
          priority: input.priority,
          projectId: input.projectId || null,
          recommendations: this.capabilities.map((capability) => `${capability} prepared for ${task.title}`),
          notes: 'Connect this agent to your LLM provider, repo tools, database, and queue worker for production execution.'
        }
      },
      ['database', 'qa']
    )
  }
}
